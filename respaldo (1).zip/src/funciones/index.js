module.exports = {
    obtenerTemplate: require('./obtenerTemplate'),
    generarTemplate: require('./generarTemplate'),
    mainPath: require('./mainPath'),
    validarUrl: require('./validarUrl'),
    obtenerConfiguracion: require('./obtenerConfiguracion'),
    obtenerCarpetaActual: require('./obtenerCarpetaActual'),
    obtenerPlantillasInstaladas: require('./obtenerPlantillasInstaladas'),
    capitalize: require('./capitalize'),
    generarSchema: require('./generarSchema'),
};