module.exports = (schemaId, inputs) => {
    let schema = {
        id: schemaId,
        type: 'object',
        required: [],
        properties: {},
    };

    inputs.forEach(input => {

        if (input.requerido && schemaId !== 'actualizar') {
            schema.required.push(input.nombre);
        }

        let nueva_propiedad = {
            type: input.tipo,
        };

        if (input.tipo === 'string' && input.requerido) {
            nueva_propiedad.pattern = '^(?![nN][uU][lL]{2}$)\\s*\\S.*';
        }

        schema.properties[input.nombre] = nueva_propiedad;
    });

    return schema;
}