var inquirer = require('inquirer');
const moment = require('moment');
const { generarTemplate, generarSchema, obtenerConfiguracion } = require('../../funciones');

const preguntar_por_atributos = async (respuestas) => {
    let atributos = [];

    console.log('----------- Para finalizar presiona ENTER sin ingresar el nombre -----------');

    for (let numero = 1; numero < 100; numero++) {
        console.log(`----------- Agregar atributo ${numero} -----------`);

        let respuestas = await inquirer.prompt([
            {
                name: 'nombre',
                message: `Nombre`,
                type: 'input',
            },
            {
                name: 'tipo',
                message: `Tipo`,
                type: 'list',
                choices: [
                    'string',
                    'number',
                    'bolean',
                    'object',
                    'array',
                ],
                when: (values) => {
                    return values.nombre;
                },
            },
            {
                name: 'requerido',
                message: 'Requerido',
                type: 'confirm',
                when: (values) => {
                    return values.nombre;
                },
            }
        ]);

        if (!respuestas.nombre) {
            break;
        }

        atributos.push(respuestas);
    }

    return atributos;
};

module.exports.nombre = 'Lambda CRUD';

module.exports.funcion = async () => {

    let configuracion = await obtenerConfiguracion();
    let respuestas = {
        usuario_nombre: configuracion.nombre,
        usuario_email: configuracion.email,
        fecha: moment().format('DD/MM/YYYY'),
        lambda_servicio: '',
        lambda_paquete: '',
        dynamo_tabla: '',
        endpoint_crud: '',
        apigateway_resource: '',
        habilitar_assume_role: '',
        ignorar_archivos: [],
        tag_proyecto: null,
        tags_servicio: '',
        agregar_tags: false
    };

    respuestas = {
        ...respuestas,
        ...await inquirer.prompt([
            {
                name: 'lambda_servicio',
                message: `Nombre del servicio`,
                type: 'input',
                askAnswered: true,
                validate: (value) => {
                    if (!value) {
                        return 'Requerido';
                    }

                    if ((value).toString().length > 39) {
                        return `El nombre del servicio debe ser menor a 39 caracteres`;
                    }

                    return true;
                }
            },
            {
                name: 'lambda_paquete',
                message: 'Nombre del paquete',
                type: 'input',
                validate: (value) => {
                    if (!value) {
                        return 'Requerido';
                    }

                    return true;
                }
            },
            {
                name: 'dynamo_tabla',
                message: 'Nombre de la tabla',
                type: 'input',
                validate: (value) => {
                    if (!value) {
                        return 'Requerido';
                    }

                    return true;
                }
            },
            {
                name: 'endpoint_crud',
                message: 'EndPoint',
                type: 'input',
                default: (values) => {
                    return `v1/${values.dynamo_tabla || ''}`.toLowerCase();
                },
                validate: (value) => {
                    if (!value) {
                        return 'Requerido';
                    }

                    return true;
                }
            },
            {
                name: 'apigateway_resource',
                message: 'Apigateway resource',
                type: 'input',
                default: (values) => {
                    return `ApiGatewayResource`;
                }
            },
            {
                name: 'habilitar_authorizer',
                message: '¿Habilitar Authorizer?',
                type: 'confirm',
                default: false
            },
            {
                name: 'lambda_eods_enviar',
                message: 'Agregar configuración para enviar al EODS',
                type: 'confirm',
                default: false
            },
            {
                name: 'lambda_eods_event',
                message: 'Nombre del evento a enviar',
                type: 'input',
                when: (values) => {
                    return values.lambda_eods_enviar;
                }
            },
            {
                name: 'habilitar_assume_role',
                message: 'Agregar invocación de lambdas externas',
                type: 'confirm',
                default: false
            },
            {
                name: 'tag_proyecto',
                message: 'Ingrese la etiqueta del proyecto (OPCIONAL)',
                type: 'input',
                default: null
            },
            {
                name: 'agregar_tags',
                message: '¿Agregar etiquetas adicionales al servicio?',
                type: 'confirm',
                default: true
            },
            {
                name: 'tags_servicio',
                message: 'Ingrese los tags separados por coma',
                type: 'input',
                when: answers => answers.agregar_tags,
                default: 'MiTag',
                validate: (value) => {
                    if(!value){
                        return 'Requerido';
                    }
                    return true;
                }
            },
            {
                name: 'agregar_atributos',
                message: '¿Agregar atributos?',
                type: 'confirm',
                default: true
            }
        ])
    };

    // preguntar por los atributos
    respuestas.atributos = respuestas.agregar_atributos ? await preguntar_por_atributos(respuestas) : [];

    respuestas.schema = JSON.stringify({
        insertar: generarSchema('insertar', respuestas.atributos),
        actualizar: generarSchema('actualizar', respuestas.atributos),
    }, null, 4);

    if (!respuestas.habilitar_assume_role) {
        respuestas.ignorar_archivos.push('servicios/invocaLambdaExterna.js');
    }

    await generarTemplate('/lambda_crud/template/', respuestas);
}