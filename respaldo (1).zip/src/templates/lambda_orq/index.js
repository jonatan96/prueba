var inquirer = require('inquirer');
const moment = require('moment');
const { generarTemplate, obtenerCarpetaActual, obtenerConfiguracion } = require('../../funciones');

module.exports.nombre = 'Lambda ORQ';

module.exports.funcion = async () => {

    let lista_permisos = {
        'Invocar Lambda': 'invocar_lambda',
        'Invocar SQS': 'invocar_sqs',
        'Invocar Step Function': 'invocar_step_function',
        'Invocar Lambdas externas': 'invocar_lambdas_externas',
        'Consultar Dynamo': 'consultar_dynamo',
        'Consultar Secret Manager': 'consultar_secret_manager',
    };

    let lista_eventos = {
        'ARN': 'arn',
        'Api Gateway': 'apigateway',
        'SQS': 'sqs',
    };

    let configuracion = await obtenerConfiguracion();
    let respuestas = {
        usuario_nombre: configuracion.nombre,
        usuario_email: configuracion.email,
        fecha: moment().format('DD/MM/YYYY'),
        servicio: '',
        paquete: '',
        habilitar_autorizador: false,
        lambda_endpoint: '',
        lambda_method: '',
        permisos: {},
        ignorar_archivos: [],
        agregar_tags: false,
        tag_proyecto: null,
        tags_servicio: '',
        tags_formateados: [],
        tipo_evento: '',
    };

    respuestas = {
        ...respuestas,
        ...await inquirer.prompt([
            {
                name: 'servicio',
                message: `Nombre del servicio`,
                type: 'input',
                default: obtenerCarpetaActual(),
                askAnswered: true,
                validate: (value) => {
                    if( !value ){
                        return 'Requerido';
                    }

                    if( (value).toString().length > 39 ){
                        return `El nombre del servicio debe ser menor a 39 caracteres`;
                    }

                    return true;
                }
            },
            {
                name: 'paquete',
                message: 'Nombre del paquete',
                type: 'input',
                default: obtenerCarpetaActual(),
                validate: (value) => {
                    if( !value ){
                        return 'Requerido';
                    }

                    return true;
                }
            },
            {
                name: 'tipo_evento',
                message: 'Evento para consumir',
                type: 'list',
                choices: Object.keys(lista_eventos),
                default: Object.keys(lista_eventos)[0],
                filter: (value) => {
                    return lista_eventos[value];
                }
            },
            // configuracion para apigateway
            {
                name: 'lambda_endpoint',
                message: 'EndPoint',
                type: 'input',
                when: (values) => values.tipo_evento === 'apigateway',
                default: (values) => {
                    return `v1/${values.servicio}`
                },
                validate: (value) => {
                    if( !value ){
                        return 'Requerido';
                    }

                    return true;
                }
            },
            {
                name: 'lambda_method',
                message: 'Metodo para consumir',
                type: 'list',
                choices: ['get', 'post', 'put', 'delete'],
                when: (values) => values.tipo_evento === 'apigateway',
                default: 'post'
            },
            {
                name: 'habilitar_autorizador',
                message: '¿Habilitar Autorizador?',
                type: 'confirm',
                default: false,
                when: (values) => values.tipo_evento === 'apigateway',
            },

            // otras configuraciones
            {
                name: 'habilitar_vpc',
                message: 'Agregar configuración para VPC',
                type: 'confirm',
                default: false,
            },
            {
                name: 'permisos',
                message: `Permisos requeridos`,
                type: 'checkbox',
                choices: Object.keys(lista_permisos),
                default: [Object.keys(lista_permisos)[0]],
            },
            {
                name: 'tag_proyecto',
                message: 'Ingrese la etiqueta del proyecto (OPCIONAL)',
                type: 'input',
                default: null
            },
            {
                name: 'agregar_tags',
                message: '¿Agregar etiquetas adicionales al servicio?',
                type: 'confirm',
                default: false
            },
            {
                name: 'tags_servicio',
                message: 'Ingrese los tags separados por coma',
                type: 'input',
                when: answers => answers.agregar_tags,
                default: 'MiTag',
                validate: (value) => {
                    if(!value){
                        return 'Requerido';
                    }
                    return true;
                }
            }
        ])
    };

    // generar el objeto de los permisos
    respuestas.permisos = respuestas.permisos.reduce((pv, cv) => {
        pv[ lista_permisos[cv] ] = true;
        return pv;
    }, {});

    respuestas.ignorar_archivos = [];

    if( !respuestas.permisos.invocar_lambdas_externas ){
        respuestas.ignorar_archivos.push('servicios/invocaLambdaExterna.js');
    }

    await generarTemplate('/lambda_orq/template/', respuestas);
}