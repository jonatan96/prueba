var AWS = require('aws-sdk');
var stepFunction = new AWS.StepFunctions();

module.exports = async (step, payload) => {
    return new Promise(async (resolve, reject) => {
        try {

            var params = {
                stateMachineArn: step,
                input: JSON.stringify(payload)
            };

            console.log(`Invocando step function ${step} con parametros: ${JSON.stringify(params)}`);

            let result = await stepFunction.startExecution(params).promise();

            console.log(`Resultado step function ${step} con parametros: ${JSON.stringify(result)}`);

            return resolve(result);
        } catch (err) {
            console.log('Error al invocar step function', JSON.stringify(err));
            return reject(err);
        }
    });
};