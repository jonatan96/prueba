var AWS = require('aws-sdk');
var sqs = new AWS.SQS({
    region: 'us-east-1'
});

module.exports = async (params) => {
    return new Promise(async (resolve, reject) => {
        try {

            console.log(`Invocando sqs ${params.QueueUrl} con parametros: ${JSON.stringify(params)}`);

            let result = await sqs.sendMessage(params).promise();;

            console.log(`Resultado sqs ${params.QueueUrl} con parametros: ${JSON.stringify(result)}`);

            return resolve(result);
        } catch (err) {
            console.log('Error al invocar sqs: ' + JSON.stringify(err));
            return reject(err);
        }
    });
};