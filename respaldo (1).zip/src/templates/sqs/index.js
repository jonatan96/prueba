var inquirer = require('inquirer');
const moment = require('moment');
const { generarTemplate, obtenerConfiguracion, obtenerCarpetaActual } = require('../../funciones');

module.exports.nombre = 'SQS';

module.exports.funcion = async () => {

    let configuracion = await obtenerConfiguracion();
    let respuestas = {
        usuario_nombre: configuracion.nombre,
        usuario_email: configuracion.email,
        fecha: moment().format('DD/MM/YYYY'),
        paquete: '',
        servicio: '',
    };

    respuestas = {
        ...respuestas,
        ...await inquirer.prompt([
            {
                name: 'paquete',
                message: `Nombre del paquete`,
                type: 'input',
                askAnswered: true,
                validate: (value) => {
                    if( !value ){
                        return 'Requerido';
                    }

                    return true;
                },
            },
            {
                name: 'servicio',
                message: `Nombre del servicio`,
                type: 'input',
                default: obtenerCarpetaActual(),
                askAnswered: true,
                validate: (value) => {
                    if( !value ){
                        return 'Requerido';
                    }

                    if( (value).toString().length > 39 ){
                        return `El nombre del servicio debe ser menor a 39 caracteres`;
                    }

                    return true;
                }
            }
        ])
    };

    await generarTemplate('/sqs/template/', respuestas);
}