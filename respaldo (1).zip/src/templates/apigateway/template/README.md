﻿[![N|Solid](https://www.frd.org.mx/img/lg-fundacionDonde.png)](https://frd.org.mx/)
apigateway-<%=paquete%>
==========

Autor: <%=usuario_nombre%>
Email: [<%=usuario_email%>](<%=usuario_email%>)
Fecha: <%=fecha%>

## Como empezar

Este proyecto utiliza el framework serverless para subir el Api a AWS.


### Pre-Requisitos

* Serverless framework
* Node JS > 8
* Cuenta de AWS
* Key y Secret Key para realizar deploy
* En el archivo serverless.yml, cambiar el profile por el configurado en el archivo credencials 

### Implementación del Aplicativo

Ejecutar los siguientes comandos:

* npm i
* sls deploy