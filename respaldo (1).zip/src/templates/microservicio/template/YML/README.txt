##############################################
# Leer las siguientes instrucciones ##########
##############################################
Dentro de la carpeta "SPE-*" copiar los archivos del proyecto
Modifcar los archivos en la carpeta "SPE-*/configuraciones" con las rutas del ambiente