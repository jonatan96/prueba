exports.basicos = async function (req, info, res) {

}