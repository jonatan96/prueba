#instalar los paquetes
`npm i`

#instalar localmente
`npm link`

#utilizar
`frd-cli`