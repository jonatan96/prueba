![enter image description here](https://www.bmv.com.mx/docs-pub/GESTOR/IMAGENES_EMISORAS/32873.jpg)

Plantillas
==========

<strong>Autor:</strong> Edward paulino xuluc chulim<br>
<strong>Email:</strong> [exuluc@frd.org.mx](exuluc@frd.org.mx)<br>
<strong>Fecha:</strong> 26-11-2020<br>

## Instrucciones
Crea una carpeta en la cual clonaras este repositorio. Importante esta carpeta no se debe mover.

### Clonar el repositorio
```shell
git clone repositorio.git
```

### Instalar las dependencias
```shell
npm install
```

### Agregar el comando al npm
```shell
npm link
```

### Como utilizar
1. Crear una carpeta en la cual generaras el nuevo proyecto e ingresa
```shell
mkdir nuevo-proyecto && cd nuevo-proyecto
```

2. Ejecutar el comando y responde las preguntas que te seran solicitadas
```shell
frd-plantilla
```

3. Sigue las instrucciones del README.md del proyecto generado